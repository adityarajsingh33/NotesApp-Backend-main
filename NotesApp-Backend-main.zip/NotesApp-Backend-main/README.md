# Notes_Application_Backend
This repo consists of the backend for the notes application.
